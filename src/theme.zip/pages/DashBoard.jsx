import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  CarFront,
  IndianRupee,
  LogIn,
  LogOut as ExitIcon,
  TrendingUp,
  Bike,
  Truck,
  Bus,
} from "lucide-react";
import { PlateBadge, StatusPill, formatDateTime } from "../components/shared";

const MOCK_SUMMARY = {
  vehiclesParked: 47,
  todayRevenue: 6280,
  todayEntries: 63,
  todayExits: 52,
  occupancyByType: [
    { type: "Car", count: 24 },
    { type: "Two-Wheeler", count: 15 },
    { type: "Truck", count: 5 },
    { type: "Bus", count: 3 },
  ],
};

const MOCK_ACTIVITY = [
  {
    id: 1,
    vehicleNumber: "TN 09 AB 1234",
    vehicleType: "Car",
    timestamp: "2026-07-25T09:47:00",
    status: "PAID",
  },
  {
    id: 2,
    vehicleNumber: "TN 22 CD 4521",
    vehicleType: "Two-Wheeler",
    timestamp: "2026-07-25T09:32:00",
    status: "PENDING",
  },
  {
    id: 3,
    vehicleNumber: "TN 07 XY 9087",
    vehicleType: "Truck",
    timestamp: "2026-07-25T09:15:00",
    status: "PAID",
  },
  {
    id: 4,
    vehicleNumber: "TN 14 LM 3390",
    vehicleType: "Bus",
    timestamp: "2026-07-25T08:58:00",
    status: "PAID",
  },
  {
    id: 5,
    vehicleNumber: "TN 09 QR 5567",
    vehicleType: "Car",
    timestamp: "2026-07-25T08:41:00",
    status: "PENDING",
  },
];

const OCCUPANCY_ICONS = {
  Car: CarFront,
  "Two-Wheeler": Bike,
  Truck: Truck,
  Bus: Bus,
};

const MetricCard = ({ label, value, icon: Icon, gradient, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.3, delay }}
    className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"
  >
    <div className="flex items-start justify-between">
      <div>
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">
          {label}
        </p>
        <p className="text-2xl font-bold text-slate-800">{value}</p>
      </div>
      <div
        className="w-11 h-11 rounded-2xl flex items-center justify-center text-white shrink-0"
        style={{ background: gradient }}
      >
        <Icon size={20} strokeWidth={2.2} />
      </div>
    </div>
  </motion.div>
);

const OccupancyRow = ({ type, count, percent }) => {
  const Icon = OCCUPANCY_ICONS[type] || CarFront;
  return (
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
        <Icon size={15} strokeWidth={2.2} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <p className="text-sm font-medium text-slate-700">{type}</p>
          <p className="text-xs font-semibold text-slate-500">{count}</p>
        </div>
        <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
          <div
            className="h-full rounded-full"
            style={{
              width: `${percent}%`,
              background: "linear-gradient(135deg, #2563EB, #06B6D4)",
            }}
          />
        </div>
      </div>
    </div>
  );
};

const Dashboard = () => {
  const [summary] = useState(MOCK_SUMMARY);
  const [activity] = useState(MOCK_ACTIVITY);

  const maxOccupancy = Math.max(1, ...summary.occupancyByType.map((o) => o.count));

  return (
    <div className="w-full space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">Dashboard</h1>
        <p className="text-sm text-slate-400 mt-0.5">
          Today's overview at a glance
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          label="Vehicles parked now"
          value={summary.vehiclesParked}
          icon={CarFront}
          gradient="linear-gradient(135deg, #2563EB, #06B6D4)"
          delay={0}
        />
        <MetricCard
          label="Today's revenue"
          value={
            <span className="inline-flex items-center gap-0.5">
              <IndianRupee size={20} />
              {summary.todayRevenue}
            </span>
          }
          icon={TrendingUp}
          gradient="linear-gradient(135deg, #0EA5A0, #14B8A6)"
          delay={0.05}
        />
        <MetricCard
          label="Today's entries"
          value={summary.todayEntries}
          icon={LogIn}
          gradient="linear-gradient(135deg, #7C3AED, #A855F7)"
          delay={0.1}
        />
        <MetricCard
          label="Today's exits"
          value={summary.todayExits}
          icon={ExitIcon}
          gradient="linear-gradient(135deg, #D97706, #F59E0B)"
          delay={0.15}
        />
      </div>

      <div className="grid lg:grid-cols-[340px_minmax(0,1fr)] gap-4 items-start">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-sm font-bold text-slate-800 mb-4">
            Occupancy by vehicle type
          </p>
          <div className="space-y-4">
            {summary.occupancyByType.map((o) => (
              <OccupancyRow
                key={o.type}
                type={o.type}
                count={o.count}
                percent={Math.round((o.count / maxOccupancy) * 100)}
              />
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100">
            <p className="text-sm font-bold text-slate-800">Recent activity</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wide text-slate-400 border-b border-slate-100">
                  <th className="px-5 py-3 font-semibold">Vehicle</th>
                  <th className="px-3 py-3 font-semibold">Type</th>
                  <th className="px-3 py-3 font-semibold">Time</th>
                  <th className="px-5 py-3 font-semibold text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {activity.map((row, i) => (
                  <tr
                    key={row.id ?? `${row.vehicleNumber}-${i}`}
                    className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60 transition-colors duration-150"
                  >
                    <td className="px-5 py-3">
                      <PlateBadge value={row.vehicleNumber} size="sm" />
                    </td>
                    <td className="px-3 py-3 text-slate-600">
                      {row.vehicleType || "—"}
                    </td>
                    <td className="px-3 py-3 text-slate-500 whitespace-nowrap">
                      {formatDateTime(row.timestamp)}
                    </td>
                    <td className="px-5 py-3 text-right">
                      <StatusPill status={row.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;