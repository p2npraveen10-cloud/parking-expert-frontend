import React, { useState, useEffect, useCallback,useRef } from "react";
import {
  User, Building2, Phone, MapPin, CalendarDays, Users as UsersIcon,
  CalendarClock, Building, BadgeCheck, Pencil, Check, Loader2, WifiOff,
  RefreshCcw, IdCard, Mail, Hash, Paperclip, Download, FileText,
  FileSpreadsheet, FileIcon, FileUp, FileDown, ArrowLeftRight, Send,
  Plus, Clock, Globe, X, ShieldCheck,Camera
} from "lucide-react";

import { useToast } from "../../context/ToastContext";
import {
  getUserProfile,
  updateUserProfile,
  getCompanyDetails,
  updateCompanyDetails,
  exportCompanyJson,
  exportCompanyCsv,
  exportCompanyExcel,
  importCompanyData,
  getReportSchedule,
  saveReportSchedule,
  uploadProfilePicture,
} from "../../serviceCalls/apiCall";

import {
  FONT_DISPLAY,
  FONT_BODY,
  FONT_MONO,
  TOKENS,
  glossyInputClass,
  glossyInputStyle,
  RippleButton,
  FieldShell,
  Dropdown,
  Modal,
  ProfileSkeleton,
  formatMemberSince,
  formatScheduleSummary,
  extractScheduleList,
  FREQUENCY_OPTIONS,
  DAY_OF_WEEK_OPTIONS,
  TIMEZONE_OPTIONS,
  CONTENT_TYPE_OPTIONS,
  pad2,
} from "./manageShared";

/* ------------------------------------------------------------------ */
/* ProfileTab                                                          */
/* ------------------------------------------------------------------ */
const ProfileTab = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(null);

  // --- avatar upload state ---
  const [avatarFile, setAvatarFile] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const fileInputRef = useRef(null);

  const toast = useToast();

    /** Keep headbar (Header.jsx) in sync with the latest profile */
  const syncHeaderUser = useCallback((p) => {
    if (!p) return;
    try {
      const raw = localStorage.getItem("user");
      const current = raw ? JSON.parse(raw) : {};
      const next = {
        ...current,
        firstName: p.firstName ?? current.firstName,
        lastName: p.lastName ?? current.lastName,
        profile: p.profile ?? current.profile,
        role: p.role ?? current.role,
        emailId: p.emailId ?? current.emailId,
        contactNo: p.contactNo ?? current.contactNo,
        mobileNumber: p.mobileNumber ?? current.mobileNumber,
        address: p.address ?? current.address,
        gender: p.gender ?? current.gender,
        dateOfBirth: p.dateOfBirth ?? current.dateOfBirth,
        company: p.company ?? current.company,
      };
      localStorage.setItem("user", JSON.stringify(next));
      window.dispatchEvent(new Event("user-profile-updated"));
    } catch (_) {
      /* ignore */
    }
  }, []);

  const loadProfile = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await getUserProfile();
      const p = data?.data ?? data;
      setProfile(p);
      syncHeaderUser(p);
    } catch (err) {
      setError(err?.response?.data?.message || err?.message || "Couldn't load your profile.");
    } finally {
      setLoading(false);
    }
  }, [syncHeaderUser]);

  useEffect(() => {
    loadProfile();
  }, [loadProfile]);

  const startEdit = () => {
    if (!profile) return;
    setForm({
      firstName: profile.firstName || "",
      lastName: profile.lastName || "",
      dateOfBirth: profile.dateOfBirth || "",
      mobileNumber: profile.mobileNumber || profile.contactNo || "",
      address: profile.address || "",
      contactNo: profile.contactNo || "",
      gender: profile.gender || "",
    });
    setAvatarFile(null);
    setAvatarPreview(null);
    setEditing(true);
  };

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleAvatarPick = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast?.error("Invalid file", "Please choose an image file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast?.error("File too large", "Please choose an image under 5MB.");
      return;
    }

    setAvatarFile(file);
    setAvatarPreview(URL.createObjectURL(file));
  };

  useEffect(() => {
    return () => {
      if (avatarPreview) URL.revokeObjectURL(avatarPreview);
    };
  }, [avatarPreview]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (avatarFile) {
        setUploadingAvatar(true);
        try {
          const formData = new FormData();
          formData.append("profilePicture", avatarFile);
          await uploadProfilePicture(formData);
        } catch (err) {
          const message = err?.response?.data?.message || err?.message || "Couldn't upload photo.";
          toast?.error("Photo upload failed", message);
          setUploadingAvatar(false);
          setSaving(false);
          return;
        }
        setUploadingAvatar(false);
      }

      await updateUserProfile(form);

      // Update headbar immediately
      syncHeaderUser({
        ...profile,
        ...form,
      });

      toast?.success("Profile updated", "Your changes were saved successfully.");
      setEditing(false);
      setAvatarFile(null);
      setAvatarPreview(null);
      await loadProfile();
    } catch (err) {
      const message = err?.response?.data?.message || err?.message || "Couldn't save changes.";
      toast?.error("Update failed", message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <ProfileSkeleton />;

  if (error) {
    return (
      <div
        className="pe-animate-up flex items-center justify-between gap-4 rounded-2xl border bg-white px-5 py-4 shadow-sm"
        style={{ borderColor: "#E8EDF5" }}
      >
        <div className="flex items-center gap-4">
          <div
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
            style={{ background: `color-mix(in srgb, ${TOKENS.blue} 10%, white)`, color: TOKENS.blue }}
          >
            <WifiOff size={18} />
          </div>
          <div>
            <p className="text-[13px] font-bold" style={{ color: TOKENS.ink }}>
              Profile unavailable
            </p>
            <p className="mt-1 text-[11.5px]" style={{ color: TOKENS.inkSoft }}>
              {error}
            </p>
          </div>
        </div>
        <button
          onClick={loadProfile}
          className="flex h-9 w-9 items-center justify-center rounded-xl border transition hover:scale-105 active:scale-95"
          style={{ borderColor: TOKENS.line, color: TOKENS.blue, background: `color-mix(in srgb, ${TOKENS.blue} 6%, white)` }}
          title="Retry"
        >
          <RefreshCcw size={15} />
        </button>
      </div>
    );
  }

  if (!profile) return null;

  const fullName = [profile.firstName, profile.lastName].filter(Boolean).join(" ") || "—";
  const initials =
    [profile.firstName, profile.lastName]
      .filter(Boolean)
      .map((s) => s[0]?.toUpperCase())
      .join("") || "—";

  const accentCycle = [TOKENS.indigo, TOKENS.blue, TOKENS.cyan];
  const infoItems = [
    { icon: Phone, label: "Contact number", value: profile.contactNo, mono: true },
    { icon: MapPin, label: "Address", value: profile.address },
    { icon: CalendarDays, label: "Date of birth", value: profile.dateOfBirth, mono: true },
    { icon: UsersIcon, label: "Gender", value: profile.gender },
    { icon: Building2, label: "Company", value: profile.company },
    { icon: CalendarClock, label: "Member since", value: formatMemberSince(profile.createdAt) },
  ];

  const avatarSrc = avatarPreview || profile.profile;

  return (
    <div className="pe-animate-up flex flex-col gap-5">
      <div className="rounded-[28px]">
        <div
          className="relative overflow-hidden rounded-[28px] px-6 pb-16 pt-8"
          style={{ background: `linear-gradient(155deg, ${TOKENS.blue} 0%, ${TOKENS.cyan} 55%, ${TOKENS.cyan} 150%)` }}
        >
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.08]"
            style={{
              backgroundImage: "radial-gradient(rgba(255,255,255,0.9) 1px, transparent 1px)",
              backgroundSize: "18px 18px",
            }}
          />
          <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-white/10 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 left-24 h-40 w-40 rounded-full bg-white/10 blur-3xl" />

          <div className="relative flex flex-wrap items-start justify-between gap-5">
            <div className="flex items-center gap-4">
              <div className="relative shrink-0">
                {avatarSrc ? (
                  <img
                    src={avatarSrc}
                    alt={fullName}
                    className="h-[88px] w-[88px] rounded-[24px] object-cover ring-[3px] ring-white/40"
                    style={{ boxShadow: "0 16px 34px -12px rgba(0,0,0,0.55)" }}
                  />
                ) : (
                  <div
                    className="flex h-[88px] w-[88px] items-center justify-center rounded-[24px] bg-white/15 text-[24px] font-extrabold text-white ring-[3px] ring-white/30 backdrop-blur-md"
                    style={{ fontFamily: FONT_DISPLAY, boxShadow: "0 16px 34px -12px rgba(0,0,0,0.55)" }}
                  >
                    {initials}
                  </div>
                )}

                {!editing && (
                  <div
                    className="absolute -bottom-1.5 -right-1.5 flex h-7 w-7 items-center justify-center rounded-full ring-[3px] ring-white"
                    style={{ background: TOKENS.cyan }}
                    title="Verified account"
                  >
                    <BadgeCheck size={14} className="text-white" />
                  </div>
                )}

                {editing && (
                  <>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleAvatarPick}
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploadingAvatar}
                      className="absolute inset-0 flex items-center justify-center rounded-[24px] bg-black/45 opacity-0 transition hover:opacity-100"
                      title="Change photo"
                    >
                      {uploadingAvatar ? (
                        <Loader2 size={18} className="pe-refresh-spin text-white" />
                      ) : (
                        <Camera size={18} className="text-white" />
                      )}
                    </button>
                  </>
                )}
              </div>

              <div className="min-w-0 pt-0.5">
                <p
                  className="truncate text-[23px] font-extrabold leading-tight tracking-tight text-white"
                  style={{ fontFamily: FONT_DISPLAY }}
                >
                  {fullName}
                </p>
                <div className="mt-1 h-[3px] w-10 rounded-full" style={{ background: "rgba(255,255,255,0.55)" }} />
                <p className="mt-2.5 truncate text-[12.5px] font-medium text-white/80">{profile.emailId || "—"}</p>
                <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[11px] font-semibold uppercase tracking-wide text-white/90">
                  <span className="inline-flex items-center gap-1.5">
                    <ShieldCheck size={12} /> {profile.role || "—"}
                  </span>
                  <span className="h-1 w-1 rounded-full bg-white/40" />
                  <span className="inline-flex items-center gap-1.5">
                    <Building size={12} /> {profile.company || "—"}
                  </span>
                </div>
              </div>
            </div>

            {!editing && (
              <RippleButton
                variant="secondary"
                onClick={startEdit}
                className="!border-white/30 !bg-white/15 !text-white shadow-[0_10px_24px_-10px_rgba(0,0,0,0.55)] backdrop-blur hover:!bg-white/25"
              >
                <Pencil size={13} /> Edit profile
              </RippleButton>
            )}
          </div>
        </div>

        <div
          className="relative z-10 -mt-10 rounded-[24px] border bg-white shadow-[0_24px_60px_-30px_rgba(15,23,42,0.45)]"
          style={{ borderColor: TOKENS.line }}
        >
          {!editing && (
            <div className="grid grid-cols-1 gap-3 p-5 sm:grid-cols-2 lg:grid-cols-3">
              {infoItems.map((item, i) => {
                const accent = accentCycle[i % accentCycle.length];
                return (
                  <div
                    key={item.label}
                    className="group relative overflow-hidden rounded-2xl border p-4 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_14px_30px_-18px_rgba(15,23,42,0.35)]"
                    style={{ borderColor: TOKENS.line, background: `color-mix(in srgb, ${accent} 3%, white)` }}
                  >
                    <div className="absolute inset-y-0 left-0 w-[3px]" style={{ background: accent }} />
                    <div className="flex items-start gap-3 pl-1.5">
                      <div
                        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                        style={{ background: `color-mix(in srgb, ${accent} 14%, white)`, color: accent }}
                      >
                        <item.icon size={16} />
                      </div>
                      <div className="min-w-0">
                        <p className="text-[10.5px] font-bold uppercase tracking-wide" style={{ color: TOKENS.inkSoft }}>
                          {item.label}
                        </p>
                        <p
                          className={`mt-1 truncate text-[13.5px] font-semibold ${item.mono ? "font-mono tabular-nums" : ""}`}
                          style={{ color: TOKENS.ink }}
                        >
                          {item.value || "—"}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {editing && form && (
            <form onSubmit={handleSave} className="p-5">
              <div
                className="rounded-2xl border p-4 transition-shadow focus-within:shadow-[0_0_0_3px_color-mix(in_srgb,var(--pe-blue)_18%,transparent)]"
                style={{ borderColor: TOKENS.line, background: `color-mix(in srgb, ${TOKENS.blue} 2.5%, white)`, "--pe-blue": TOKENS.blue }}
              >
                <div className="mb-3 flex items-center gap-2.5">
                  <div
                    className="flex h-8 w-8 items-center justify-center rounded-lg text-white"
                    style={{ background: `linear-gradient(135deg, ${TOKENS.blue}, ${TOKENS.cyan})` }}
                  >
                    <IdCard size={15} />
                  </div>
                  <p className="text-[13px] font-bold" style={{ color: TOKENS.ink }}>
                    Personal details
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3.5">
                  <FieldShell label="First name" icon={IdCard}>
                    <input required className={glossyInputClass} style={glossyInputStyle} value={form.firstName} onChange={set("firstName")} />
                  </FieldShell>
                  <FieldShell label="Last name" icon={IdCard}>
                    <input className={glossyInputClass} style={glossyInputStyle} value={form.lastName} onChange={set("lastName")} />
                  </FieldShell>
                  <FieldShell label="Date of birth" icon={CalendarDays}>
                    <input type="date" className={glossyInputClass} style={glossyInputStyle} value={form.dateOfBirth} onChange={set("dateOfBirth")} />
                  </FieldShell>
                  <FieldShell label="Gender">
                    <Dropdown
                      value={form.gender}
                      onChange={(v) => setForm((f) => ({ ...f, gender: v }))}
                      width="100%"
                      options={[
                        { value: "Male", label: "Male" },
                        { value: "Female", label: "Female" },
                        { value: "Other", label: "Other" },
                      ]}
                    />
                  </FieldShell>
                </div>
              </div>

              <div
                className="mt-3.5 rounded-2xl border p-4 transition-shadow focus-within:shadow-[0_0_0_3px_color-mix(in_srgb,var(--pe-indigo)_18%,transparent)]"
                style={{ borderColor: TOKENS.line, background: `color-mix(in srgb, ${TOKENS.indigo} 2.5%, white)`, "--pe-indigo": TOKENS.indigo }}
              >
                <div className="mb-3 flex items-center gap-2.5">
                  <div
                    className="flex h-8 w-8 items-center justify-center rounded-lg text-white"
                    style={{ background: `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.blue})` }}
                  >
                    <Phone size={15} />
                  </div>
                  <p className="text-[13px] font-bold" style={{ color: TOKENS.ink }}>
                    Contact
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3.5">
                  <FieldShell label="Contact number" icon={Phone}>
                    <input className={glossyInputClass} style={glossyInputStyle} value={form.contactNo} onChange={set("contactNo")} />
                  </FieldShell>
                  {/* <FieldShell label="Mobile number" icon={Phone}>
                    <input className={glossyInputClass} style={glossyInputStyle} value={form.mobileNumber} onChange={set("mobileNumber")} />
                  </FieldShell> */}
                  <FieldShell label="Address" icon={MapPin}>
                    <input className={glossyInputClass} style={glossyInputStyle} value={form.address} onChange={set("address")} />
                  </FieldShell>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t pt-4" style={{ borderColor: TOKENS.line }}>
                <RippleButton type="button" variant="secondary" onClick={() => setEditing(false)} disabled={saving}>
                  Cancel
                </RippleButton>
                <RippleButton
                  type="submit"
                  disabled={saving}
                  style={{ background: `linear-gradient(135deg, ${TOKENS.blue}, ${TOKENS.cyan})`, boxShadow: `0 12px 26px -10px color-mix(in srgb, ${TOKENS.blue} 60%, transparent)` }}
                >
                  {saving ? <Loader2 size={13} className="pe-refresh-spin" /> : <Check size={13} />}
                  {saving ? "Saving…" : "Save changes"}
                </RippleButton>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

/* ------------------------------------------------------------------ */
/* Schedule helpers                                                    */
/* ------------------------------------------------------------------ */
const ScheduleToggle = ({ checked, onChange, disabled }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    disabled={disabled}
    onClick={() => onChange(!checked)}
    className="relative h-7 w-12 shrink-0 rounded-full transition-colors duration-300 disabled:opacity-50"
    style={{
      background: checked
        ? `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.cyan})`
        : "#E2E8F0",
      boxShadow: checked
        ? `0 0 0 1px color-mix(in srgb, ${TOKENS.blue} 30%, transparent), 0 4px 10px -4px color-mix(in srgb, ${TOKENS.blue} 60%, transparent)`
        : "inset 0 1px 2px rgba(15,23,42,0.12)",
    }}
  >
    <span
      className="absolute top-0.5 h-6 w-6 rounded-full bg-white transition-all duration-300"
      style={{ left: checked ? "22px" : "2px", boxShadow: "0 2px 6px rgba(15,23,42,0.25)" }}
    />
  </button>
);

const ScheduleClock = ({ hour, minute }) => {
  const hourAngle = ((hour % 12) + minute / 60) * 30;
  const minuteAngle = minute * 6;
  const rad = (deg) => (deg * Math.PI) / 180;
  return (
    <div className="pe3d-float relative mx-auto h-[132px] w-[132px]">
      <svg viewBox="0 0 200 200" className="pe3d-clock h-full w-full">
        <defs>
          <radialGradient id="peClockFace" cx="32%" cy="28%" r="85%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="60%" stopColor="#F3F6FC" />
            <stop offset="100%" stopColor="#E4EAF5" />
          </radialGradient>
          <linearGradient id="peClockRim" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={TOKENS.indigo} />
            <stop offset="55%" stopColor={TOKENS.blue} />
            <stop offset="100%" stopColor={TOKENS.cyan} />
          </linearGradient>
        </defs>
        <circle cx="100" cy="100" r="96" fill="url(#peClockRim)" />
        <circle cx="100" cy="100" r="82" fill="url(#peClockFace)" />
        {[...Array(12)].map((_, i) => {
          const a = rad(i * 30);
          const x1 = 100 + 68 * Math.sin(a);
          const y1 = 100 - 68 * Math.cos(a);
          const x2 = 100 + 76 * Math.sin(a);
          const y2 = 100 - 76 * Math.cos(a);
          return (
            <line
              key={i}
              x1={x1} y1={y1} x2={x2} y2={y2}
              stroke="#B8C4D9"
              strokeWidth={i % 3 === 0 ? 3 : 1.5}
              strokeLinecap="round"
            />
          );
        })}
        <line
          x1="100" y1="100"
          x2={100 + 40 * Math.sin(rad(hourAngle))}
          y2={100 - 40 * Math.cos(rad(hourAngle))}
          stroke={TOKENS.ink} strokeWidth="6" strokeLinecap="round"
        />
        <line
          x1="100" y1="100"
          x2={100 + 58 * Math.sin(rad(minuteAngle))}
          y2={100 - 58 * Math.cos(rad(minuteAngle))}
          stroke={TOKENS.blue} strokeWidth="4" strokeLinecap="round"
        />
        <circle cx="100" cy="100" r="6" fill={TOKENS.indigo} />
      </svg>
    </div>
  );
};

/* ------------------------------------------------------------------ */
/* CompanyTab                                                          */
/* ------------------------------------------------------------------ */
const CompanyTab = () => {
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filtering, setFiltering] = useState(false);
  const [error, setError] = useState(null);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(null);
  const [section, setSection] = useState("details");
  const [importFile, setImportFile] = useState(null);
  const [importing, setImporting] = useState(false);
  const [exporting, setExporting] = useState(null);
  const [contentType, setContentType] = useState("");
  const toast = useToast();

  const [schedules, setSchedules] = useState(null);
  const [scheduleLoading, setScheduleLoading] = useState(false);
  const [scheduleSaving, setScheduleSaving] = useState(false);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({
    frequency: "DAILY",
    hourOfDay: 9,
    minuteOfHour: 0,
    dayOfWeek: 1,
    dayOfMonth: 1,
    recipientEmail: "",
    enabled: true,
    timeZone: TIMEZONE_OPTIONS[0] || "UTC",
  });

  const defaultScheduleForm = () => ({
    frequency: "DAILY",
    hourOfDay: 9,
    minuteOfHour: 0,
    dayOfWeek: 1,
    dayOfMonth: 1,
    recipientEmail: "",
    enabled: true,
    timeZone: TIMEZONE_OPTIONS[0] || "UTC",
  });

  const loadCompany = useCallback(async ({ type = "", silent = false } = {}) => {
    if (silent) setFiltering(true);
    else {
      setLoading(true);
      setError(null);
    }
    try {
      const params = type ? { contentType: type } : undefined;
      const { data } = await getCompanyDetails(params);
      setCompany(data?.data ?? data);
    } catch (err) {
      const message =
        err?.response?.data?.message ||
        err?.message ||
        "Couldn't load company details.";
      if (!silent) setError(message);
      else toast?.error("Filter failed", message);
    } finally {
      setLoading(false);
      setFiltering(false);
    }
  }, [toast]);

  useEffect(() => {
    loadCompany({ type: "", silent: false });
  }, [loadCompany]);

  const loadSchedules = useCallback(async ({ silent = false } = {}) => {
    if (!silent) setScheduleLoading(true);
    try {
      const res = await getReportSchedule();
      const list = extractScheduleList(res?.data);
      setSchedules(list);
      if (!silent && list.length === 0) {
        console.info("[report/schedule] parsed empty list from response:", res?.data);
      }
    } catch (err) {
      console.error("[report/schedule] GET failed:", err?.response?.status, err?.response?.data || err?.message);
      setSchedules([]);
      const msg =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message ||
        "Couldn't load schedules.";
      toast?.error(
        err?.response?.status === 401 || err?.response?.status === 403
          ? "Auth required"
          : "Couldn't load schedules",
        err?.response?.status === 401 || err?.response?.status === 403
          ? "Schedule API needs the same login token as the rest of the app. Add getReportSchedule to apiCall or check localStorage token."
          : msg
      );
    } finally {
      setScheduleLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    if (section !== "reportScheduling") return;
    loadSchedules();
  }, [section, loadSchedules]);

  const handleContentTypeChange = (value) => {
    setContentType(value);
    loadCompany({ type: value, silent: true });
  };

  const startEdit = () => {
    if (!company) return;
    setForm({
      companyName: company.companyName || "",
      companyDescription: company.companyDescription || "",
      companyAddress: company.companyAddress || "",
      companyEmail: company.companyEmail || "",
      companyContactNo: company.companyContactNo || "",
      gstNumber: company.gstNumber || "",
    });
    setEditing(true);
  };

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateCompanyDetails(form);
      toast?.success("Company updated", "Company details were saved successfully.");
      setEditing(false);
      loadCompany({ type: contentType, silent: true });
    } catch (err) {
      const message = err?.response?.data?.message || err?.message || "Couldn't save changes.";
      toast?.error("Update failed", message);
    } finally {
      setSaving(false);
    }
  };

  const handleExport = async (format) => {
    setExporting(format);
    try {
      let response;
      if (format === "json") response = await exportCompanyJson();
      else if (format === "csv") response = await exportCompanyCsv();
      else response = await exportCompanyExcel();
      const data = response.data;
      const mime =
        format === "json"
          ? "application/json"
          : format === "csv"
            ? "text/csv"
            : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      const blob = new Blob([data], { type: mime });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `company-data.${format === "excel" ? "xlsx" : format}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      toast?.success("Export ready", `Your ${format.toUpperCase()} file has been downloaded.`);
    } catch (err) {
      toast?.error("Export failed", err?.response?.data?.message || err?.message || "Couldn't export data.");
    } finally {
      setExporting(null);
    }
  };

  const handleImport = async () => {
    if (!importFile) return;
    setImporting(true);
    try {
      const payload = new FormData();
      payload.append("file", importFile);
      await importCompanyData(payload);
      toast?.success("Import complete", "Your file has been imported successfully.");
      setImportFile(null);
      loadCompany({ type: contentType, silent: true });
    } catch (err) {
      toast?.error("Import failed", err?.response?.data?.message || err?.message || "Couldn't import this file.");
    } finally {
      setImporting(false);
    }
  };

  const openCreateSchedule = () => {
    setScheduleForm(defaultScheduleForm());
    setScheduleModalOpen(true);
  };

  const handleScheduleSave = async (e) => {
    e.preventDefault();
    setScheduleSaving(true);
    try {
      const payload = {
        frequency: scheduleForm.frequency,
        hourOfDay: scheduleForm.hourOfDay,
        minuteOfHour: scheduleForm.minuteOfHour,
        dayOfWeek: scheduleForm.frequency === "WEEKLY" ? scheduleForm.dayOfWeek : null,
        dayOfMonth: scheduleForm.frequency === "MONTHLY" ? scheduleForm.dayOfMonth : null,
        recipientEmail: scheduleForm.recipientEmail,
        enabled: scheduleForm.enabled,
        timeZone: scheduleForm.timeZone,
      };
      await saveReportSchedule(payload);
      toast?.success("Schedule created", "The report email schedule was saved.");
      setScheduleModalOpen(false);
      await loadSchedules({ silent: true });
    } catch (err) {
      toast?.error(
        "Save failed",
        err?.response?.data?.message || err?.message || "Couldn't save the schedule."
      );
    } finally {
      setScheduleSaving(false);
    }
  };

  if (loading) return <ProfileSkeleton />;

  if (error) {
    return (
      <div className="pe-animate-up flex items-center justify-between gap-4 rounded-2xl border bg-white px-5 py-4 shadow-sm" style={{ borderColor: "#E8EDF5" }}>
        <div className="flex items-center gap-4">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl" style={{ background: `color-mix(in srgb, ${TOKENS.blue} 10%, white)`, color: TOKENS.blue }}>
            <WifiOff size={18} />
          </div>
          <div>
            <p className="text-[13px] font-bold" style={{ color: TOKENS.ink }}>Company unavailable</p>
            <p className="mt-1 text-[11.5px]" style={{ color: TOKENS.inkSoft }}>{error}</p>
          </div>
        </div>
        <button onClick={() => loadCompany()} className="flex h-9 w-9 items-center justify-center rounded-xl border transition hover:scale-105 active:scale-95" style={{ borderColor: TOKENS.line, color: TOKENS.blue, background: `color-mix(in srgb, ${TOKENS.blue} 6%, white)` }} title="Retry">
          <RefreshCcw size={15} />
        </button>
      </div>
    );
  }

  if (!company) return null;

  const initials = (company.companyName || "—").split(" ").filter(Boolean).map((s) => s[0]?.toUpperCase()).slice(0, 2).join("");
  const statusTone = company.status === "ACTIVE" ? TOKENS.cyan : TOKENS.inkSoft;
  const accentCycle = [TOKENS.indigo, TOKENS.blue, TOKENS.cyan];
  const infoItems = [
    { icon: Mail, label: "Company email", value: company.companyEmail },
    { icon: Phone, label: "Contact number", value: company.companyContactNo, mono: true },
    { icon: MapPin, label: "Address", value: company.companyAddress },
    { icon: Hash, label: "GST number", value: company.gstNumber },
    { icon: CalendarDays, label: "Registered on", value: formatMemberSince(company.createdAt) },
    { icon: CalendarClock, label: "Last updated", value: formatMemberSince(company.updatedAt) },
  ];
  const sections = [
    { id: "details", label: "Details", icon: Building2 },
    { id: "attachments", label: "Attachments", icon: Paperclip, count: company.attachments?.length || 0 },
    { id: "importExport", label: "Import & export", icon: ArrowLeftRight },
    { id: "reportScheduling", label: "Report scheduling", icon: Send },
  ];

  const fileIcon = (type) => (type === "PDF" ? FileText : type === "EXCEL" ? FileSpreadsheet : FileIcon);
  const fileTone = (type) => (type === "PDF" ? "#E23744" : type === "EXCEL" ? "#1D7A46" : TOKENS.blue);
  const formatBytes = (n) => {
    if (!n && n !== 0) return "—";
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="pe-animate-up flex flex-col gap-5">
      <style>{`
        @keyframes pe3dFloat { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-6px); } }
        .pe3d-float { animation: pe3dFloat 4.5s ease-in-out infinite; }
        @keyframes pe3dSpin { to { transform: rotate(360deg); } }
        .pe3d-ring { animation: pe3dSpin 9s linear infinite; }
        @keyframes pe3dShimmer { 0% { transform: translateX(-130%) rotate(8deg); } 100% { transform: translateX(230%) rotate(8deg); } }
        .pe3d-shine { position: relative; overflow: hidden; }
        .pe3d-shine::after {
          content: "";
          position: absolute;
          top: -40%;
          left: 0;
          width: 26%;
          height: 180%;
          background: linear-gradient(120deg, transparent, rgba(255,255,255,0.6), transparent);
          opacity: 0;
          pointer-events: none;
        }
        .pe3d-shine:hover::after { opacity: 1; animation: pe3dShimmer 1s ease; }
        .pe3d-card { transition: transform .35s ease, box-shadow .35s ease; transform-style: preserve-3d; }
        .pe3d-card:hover { transform: translateY(-4px) rotateX(2deg) rotateY(-2deg); }
        .pe3d-clock { filter: drop-shadow(0 14px 20px rgba(30, 41, 59, 0.28)); }
        @media (prefers-reduced-motion: reduce) {
          .pe3d-float, .pe3d-ring, .pe3d-shine::after { animation: none !important; }
        }
      `}</style>

      <div className="rounded-[28px]">
        <div className="relative overflow-hidden rounded-[28px] px-6 pb-16 pt-8" style={{ background: `linear-gradient(155deg, ${TOKENS.indigo} 0%, ${TOKENS.blue} 55%, ${TOKENS.cyan} 150%)` }}>
          <div className="pointer-events-none absolute inset-0 opacity-[0.08]" style={{ backgroundImage: "radial-gradient(rgba(255,255,255,0.9) 1px, transparent 1px)", backgroundSize: "18px 18px" }} />
          <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-white/10 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 left-24 h-40 w-40 rounded-full bg-white/10 blur-3xl" />
          <div className="pointer-events-none absolute right-24 bottom-0 h-28 w-28 rounded-full bg-white/10 blur-2xl" />

          <div className="relative flex flex-wrap items-start justify-between gap-5">
            <div className="flex items-center gap-4">
              <div className="relative shrink-0" style={{ perspective: "700px" }}>
                <div
                  className="pe3d-ring absolute -inset-1.5 rounded-[28px] opacity-70"
                  style={{ background: `conic-gradient(from 0deg, ${TOKENS.cyan}, ${TOKENS.blue}, ${TOKENS.indigo}, ${TOKENS.cyan})`, filter: "blur(3px)" }}
                />
                {company.companyLogo ? (
                  <img src={company.companyLogo} alt={company.companyName} className="pe3d-card relative h-[88px] w-[88px] rounded-[24px] object-cover ring-[3px] ring-white/40" style={{ boxShadow: "0 16px 34px -12px rgba(0,0,0,0.55)" }} />
                ) : (
                  <div className="pe3d-card relative flex h-[88px] w-[88px] items-center justify-center rounded-[24px] bg-white/15 text-[24px] font-extrabold text-white ring-[3px] ring-white/30 backdrop-blur-md" style={{ fontFamily: FONT_DISPLAY, boxShadow: "0 16px 34px -12px rgba(0,0,0,0.55)" }}>
                    {initials || <Building2 size={30} />}
                  </div>
                )}
                <div className="absolute -bottom-1.5 -right-1.5 flex h-7 w-7 items-center justify-center rounded-full ring-[3px] ring-white" style={{ background: statusTone }} title={company.status}>
                  <ShieldCheck size={14} className="text-white" />
                </div>
              </div>

              <div className="min-w-0 pt-0.5">
                <p className="truncate text-[23px] font-extrabold leading-tight tracking-tight text-white" style={{ fontFamily: FONT_DISPLAY }}>{company.companyName || "—"}</p>
                <div className="mt-1 h-[3px] w-10 rounded-full" style={{ background: "rgba(255,255,255,0.55)" }} />
                <p className="mt-2.5 max-w-md truncate text-[12.5px] font-medium text-white/80">{company.companyDescription || "—"}</p>
                <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[11px] font-semibold uppercase tracking-wide text-white/90">
                  <span className="inline-flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: statusTone }} /> {company.status || "—"}
                  </span>
                  <span className="h-1 w-1 rounded-full bg-white/40" />
                  <span className="inline-flex items-center gap-1.5">
                    <Mail size={12} /> {company.companyEmail || "—"}
                  </span>
                </div>
              </div>
            </div>

            {!editing && section === "details" && (
              <RippleButton variant="secondary" onClick={startEdit} className="!border-white/30 !bg-white/15 !text-white shadow-[0_10px_24px_-10px_rgba(0,0,0,0.55)] backdrop-blur hover:!bg-white/25">
                <Pencil size={13} /> Edit company
              </RippleButton>
            )}
          </div>
        </div>

        <div className="relative z-10 -mt-10 rounded-[24px] border bg-white shadow-[0_24px_60px_-30px_rgba(15,23,42,0.45)]" style={{ borderColor: TOKENS.line }}>
          <div className="flex flex-wrap items-center gap-1.5 border-b p-3" style={{ borderColor: TOKENS.line }}>
            {sections.map((s) => {
              const active = section === s.id;
              return (
                <button
                  key={s.id}
                  onClick={() => { setSection(s.id); setEditing(false); }}
                  className="flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[12px] font-bold transition"
                  style={active
                    ? { background: `color-mix(in srgb, ${TOKENS.blue} 12%, white)`, color: TOKENS.blue, boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${TOKENS.blue} 22%, transparent)` }
                    : { color: TOKENS.inkSoft }}
                >
                  <s.icon size={14} />
                  {s.label}
                  {typeof s.count === "number" && (
                    <span className="rounded-full px-1.5 py-0.5 text-[10px]" style={{ background: active ? `color-mix(in srgb, ${TOKENS.blue} 18%, white)` : "#F1F5F9", color: active ? TOKENS.blue : TOKENS.inkSoft }}>
                      {s.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {section === "details" && !editing && (
            <div className="p-5">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {infoItems.map((item, i) => {
                  const accent = accentCycle[i % accentCycle.length];
                  return (
                    <div key={item.label} className="pe3d-card group relative overflow-hidden rounded-2xl border p-4 hover:shadow-[0_16px_34px_-18px_rgba(15,23,42,0.4)]" style={{ borderColor: TOKENS.line, background: `color-mix(in srgb, ${accent} 3%, white)` }}>
                      <div className="absolute inset-y-0 left-0 w-[3px]" style={{ background: accent }} />
                      <div className="flex items-start gap-3 pl-1.5">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl" style={{ background: `color-mix(in srgb, ${accent} 14%, white)`, color: accent, boxShadow: `0 6px 14px -8px color-mix(in srgb, ${accent} 60%, transparent)` }}>
                          <item.icon size={16} />
                        </div>
                        <div className="min-w-0">
                          <p className="text-[10.5px] font-bold uppercase tracking-wide" style={{ color: TOKENS.inkSoft }}>{item.label}</p>
                          <p className={`mt-1 truncate text-[13.5px] font-semibold ${item.mono ? "font-mono tabular-nums" : ""}`} style={{ color: TOKENS.ink }}>{item.value || "—"}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {company.owner && (
                <div className="pe3d-card mt-4 rounded-2xl border p-4" style={{ borderColor: TOKENS.line, background: "linear-gradient(180deg, #ffffff 0%, #FAFBFD 100%)" }}>
                  <p className="mb-3 text-[10.5px] font-bold uppercase tracking-wide" style={{ color: TOKENS.inkSoft }}>Company owner</p>
                  <div className="flex flex-wrap items-center gap-4">
                    {company.owner.profile ? (
                      <img src={company.owner.profile} alt={company.owner.firstName} className="h-14 w-14 rounded-2xl object-cover ring-2 ring-white" style={{ boxShadow: "0 8px 18px -8px rgba(15,23,42,0.35)" }} />
                    ) : (
                      <div className="flex h-14 w-14 items-center justify-center rounded-2xl text-[15px] font-extrabold text-white" style={{ background: `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.blue})`, fontFamily: FONT_DISPLAY }}>
                        {[company.owner.firstName, company.owner.lastName].filter(Boolean).map((s) => s[0]).join("")}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-bold" style={{ color: TOKENS.ink }}>{[company.owner.firstName, company.owner.lastName].filter(Boolean).join(" ")}</p>
                      <p className="truncate text-[12px]" style={{ color: TOKENS.inkSoft }}>{company.owner.emailId}</p>
                    </div>
                    <span className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide" style={{ background: `color-mix(in srgb, ${TOKENS.blue} 12%, white)`, color: TOKENS.blue }}>
                      <ShieldCheck size={11} /> {company.owner.role}
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold" style={{ background: "#F1F5F9", color: TOKENS.inkSoft }}>
                      <Phone size={11} /> {company.owner.contactNo || "—"}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {section === "details" && editing && form && (
            <form onSubmit={handleSave} className="p-5">
              <div className="rounded-2xl border p-4" style={{ borderColor: TOKENS.line, background: `color-mix(in srgb, ${TOKENS.blue} 2.5%, white)` }}>
                <div className="mb-3 flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg text-white" style={{ background: `linear-gradient(135deg, ${TOKENS.blue}, ${TOKENS.cyan})` }}>
                    <Building2 size={15} />
                  </div>
                  <p className="text-[13px] font-bold" style={{ color: TOKENS.ink }}>Company details</p>
                </div>
                <div className="grid grid-cols-2 gap-3.5">
                  <FieldShell label="Company name" icon={Building2}>
                    <input required className={glossyInputClass} style={glossyInputStyle} value={form.companyName} onChange={set("companyName")} />
                  </FieldShell>
                  <FieldShell label="GST number" icon={Hash}>
                    <input className={glossyInputClass} style={glossyInputStyle} value={form.gstNumber} onChange={set("gstNumber")} />
                  </FieldShell>
                  <FieldShell label="Company email" icon={Mail}>
                    <input type="email" className={glossyInputClass} style={glossyInputStyle} value={form.companyEmail} onChange={set("companyEmail")} />
                  </FieldShell>
                  <FieldShell label="Contact number" icon={Phone}>
                    <input className={glossyInputClass} style={glossyInputStyle} value={form.companyContactNo} onChange={set("companyContactNo")} />
                  </FieldShell>
                  <FieldShell label="Address" icon={MapPin}>
                    <input className={glossyInputClass} style={glossyInputStyle} value={form.companyAddress} onChange={set("companyAddress")} />
                  </FieldShell>
                </div>
                <div className="mt-3.5">
                  <FieldShell label="Description" icon={FileText}>
                    <textarea rows={3} className={glossyInputClass} style={glossyInputStyle} value={form.companyDescription} onChange={set("companyDescription")} />
                  </FieldShell>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t pt-4" style={{ borderColor: TOKENS.line }}>
                <RippleButton type="button" variant="secondary" onClick={() => setEditing(false)} disabled={saving}>Cancel</RippleButton>
                <RippleButton type="submit" disabled={saving} className="pe3d-shine" style={{ background: `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.blue})`, boxShadow: `0 12px 26px -10px color-mix(in srgb, ${TOKENS.blue} 60%, transparent)` }}>
                  {saving ? <Loader2 size={13} className="pe-refresh-spin" /> : <Check size={13} />}
                  {saving ? "Saving…" : "Save changes"}
                </RippleButton>
              </div>
            </form>
          )}

          {section === "attachments" && (
            <div className="p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <p className="text-[11px] font-bold uppercase tracking-wide" style={{ color: TOKENS.inkSoft }}>
                  Filter by content type
                </p>
                <div className="flex items-center gap-1 rounded-xl border bg-[#F8F9FC] p-1" style={{ borderColor: TOKENS.line }}>
                  {CONTENT_TYPE_OPTIONS.map((o) => {
                    const active = contentType === o.value;
                    return (
                      <button
                        key={o.value || "all"}
                        type="button"
                        onClick={() => handleContentTypeChange(o.value)}
                        disabled={filtering}
                        className="rounded-lg px-2.5 py-1.5 text-[11.5px] font-bold transition disabled:opacity-60"
                        style={{
                          fontFamily: FONT_BODY,
                          color: active ? "#fff" : TOKENS.inkSoft,
                          background: active ? `linear-gradient(135deg, ${TOKENS.blue}, ${TOKENS.cyan})` : "transparent",
                        }}
                      >
                        {o.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {filtering && (
                <div className="mb-3 flex items-center gap-2 text-[12px]" style={{ color: TOKENS.inkSoft }}>
                  <Loader2 size={14} className="pe-refresh-spin" />
                  Updating attachments…
                </div>
              )}

              {!company.attachments || company.attachments.length === 0 ? (
                <div className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed py-10 text-center" style={{ borderColor: TOKENS.line }}>
                  <Paperclip size={20} style={{ color: TOKENS.inkSoft }} />
                  <p className="text-[12.5px] font-semibold" style={{ color: TOKENS.inkSoft }}>
                    {contentType ? `No ${contentType.toUpperCase()} attachments` : "No attachments yet"}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {company.attachments.map((file) => {
                    const Icon = fileIcon(file.fileType);
                    const tone = fileTone(file.fileType);
                    return (
                      <div key={file.id} className="pe3d-card flex items-center gap-3 rounded-2xl border p-4 hover:shadow-[0_16px_34px_-18px_rgba(15,23,42,0.4)]" style={{ borderColor: TOKENS.line }}>
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl" style={{ background: `color-mix(in srgb, ${tone} 14%, white)`, color: tone }}>
                          <Icon size={18} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[13px] font-bold" style={{ color: TOKENS.ink }}>{file.fileName}</p>
                          <p className="mt-0.5 text-[11px]" style={{ color: TOKENS.inkSoft }}>{formatBytes(file.fileSize)} · {formatMemberSince(file.createdAt)}</p>
                        </div>
                        <a href={file.fileUrl} target="_blank" rel="noreferrer" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border transition hover:scale-105 active:scale-95" style={{ borderColor: TOKENS.line, color: TOKENS.blue }} title="Download">
                          <Download size={15} />
                        </a>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {section === "importExport" && (
            <div className="p-5">
              <div className="rounded-2xl border p-4" style={{ borderColor: TOKENS.line, background: `color-mix(in srgb, ${TOKENS.blue} 2.5%, white)` }}>
                <p className="mb-1 text-[13px] font-bold" style={{ color: TOKENS.ink }}>Export company data</p>
                <p className="mb-3.5 text-[11.5px]" style={{ color: TOKENS.inkSoft }}>Download your company records in the format you need.</p>
                <div className="flex flex-wrap gap-2.5">
                  {["json", "csv", "excel"].map((format) => (
                    <button
                      key={format}
                      onClick={() => handleExport(format)}
                      disabled={exporting === format}
                      className="pe3d-shine flex items-center gap-2 rounded-xl border px-4 py-2.5 text-[12px] font-bold transition hover:-translate-y-0.5"
                      style={{ borderColor: TOKENS.line, color: TOKENS.blue, background: "white" }}
                    >
                      {exporting === format ? <Loader2 size={14} className="pe-refresh-spin" /> : <FileDown size={14} />}
                      {format.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-3.5 rounded-2xl border p-4" style={{ borderColor: TOKENS.line, background: `color-mix(in srgb, ${TOKENS.indigo} 2.5%, white)` }}>
                <p className="mb-1 text-[13px] font-bold" style={{ color: TOKENS.ink }}>Import company data</p>
                <p className="mb-3.5 text-[11.5px]" style={{ color: TOKENS.inkSoft }}>Upload a JSON, CSV, or Excel file to bulk update your records.</p>
                <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border border-dashed py-8 text-center transition hover:bg-slate-50" style={{ borderColor: TOKENS.line }}>
                  <FileUp size={20} style={{ color: TOKENS.blue }} />
                  <span className="text-[12px] font-semibold" style={{ color: TOKENS.ink }}>{importFile ? importFile.name : "Click to choose a file"}</span>
                  <span className="text-[10.5px]" style={{ color: TOKENS.inkSoft }}>.json, .csv, .xlsx</span>
                  <input type="file" accept=".json,.csv,.xlsx" className="hidden" onChange={(e) => setImportFile(e.target.files?.[0] || null)} />
                </label>
                {importFile && (
                  <div className="mt-3.5 flex justify-end gap-2">
                    <RippleButton type="button" variant="secondary" onClick={() => setImportFile(null)} disabled={importing}>Clear</RippleButton>
                    <RippleButton type="button" onClick={handleImport} disabled={importing} style={{ background: `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.blue})` }}>
                      {importing ? <Loader2 size={13} className="pe-refresh-spin" /> : <FileUp size={13} />}
                      {importing ? "Importing…" : "Import file"}
                    </RippleButton>
                  </div>
                )}
              </div>
            </div>
          )}

          {section === "reportScheduling" && (
            <div className="p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-[13px] font-bold" style={{ color: TOKENS.ink }}>Scheduled reports</p>
                  <p className="mt-0.5 text-[11.5px]" style={{ color: TOKENS.inkSoft }}>
                    {schedules == null
                      ? "Loading…"
                      : schedules.length === 0
                        ? "No schedules yet"
                        : `${schedules.length} schedule${schedules.length === 1 ? "" : "s"}`}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => loadSchedules()}
                    disabled={scheduleLoading}
                    className="flex h-9 w-9 items-center justify-center rounded-xl border transition hover:scale-105 active:scale-95 disabled:opacity-50"
                    style={{ borderColor: TOKENS.line, color: TOKENS.blue, background: `color-mix(in srgb, ${TOKENS.blue} 6%, white)` }}
                    title="Refresh"
                  >
                    <RefreshCcw size={15} className={scheduleLoading ? "pe-refresh-spin" : ""} />
                  </button>
                  <RippleButton
                    type="button"
                    onClick={openCreateSchedule}
                    className="pe3d-shine"
                    style={{ background: `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.blue})`, boxShadow: `0 10px 22px -10px color-mix(in srgb, ${TOKENS.blue} 55%, transparent)` }}
                  >
                    <Plus size={14} /> Create report
                  </RippleButton>
                </div>
              </div>

              {scheduleLoading && schedules == null ? (
                <div className="flex items-center justify-center gap-2 rounded-2xl border border-dashed py-14 text-[12.5px] font-semibold" style={{ borderColor: TOKENS.line, color: TOKENS.inkSoft }}>
                  <Loader2 size={16} className="pe-refresh-spin" /> Loading schedules…
                </div>
              ) : !schedules || schedules.length === 0 ? (
                <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed py-12 text-center" style={{ borderColor: TOKENS.line }}>
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl" style={{ background: `color-mix(in srgb, ${TOKENS.blue} 12%, white)`, color: TOKENS.blue }}>
                    <Send size={20} />
                  </div>
                  <div>
                    <p className="text-[13px] font-bold" style={{ color: TOKENS.ink }}>No report schedules</p>
                    <p className="mt-1 max-w-xs text-[12px]" style={{ color: TOKENS.inkSoft }}>
                      Create a schedule to email reports automatically on a daily, weekly, or monthly cadence.
                    </p>
                  </div>
                  <RippleButton type="button" onClick={openCreateSchedule} style={{ background: `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.blue})` }}>
                    <Plus size={14} /> Create your first schedule
                  </RippleButton>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {schedules.map((s) => {
                    const summary = formatScheduleSummary({
                      frequency: s.frequency || "DAILY",
                      hourOfDay: s.hourOfDay ?? 0,
                      minuteOfHour: s.minuteOfHour ?? 0,
                      dayOfWeek: s.dayOfWeek ?? 1,
                      dayOfMonth: s.dayOfMonth ?? 1,
                    });
                    const enabled = s.enabled !== false;
                    return (
                      <div
                        key={s.id ?? s.jobKey}
                        className="pe3d-card relative overflow-hidden rounded-2xl border p-4"
                        style={{ borderColor: TOKENS.line, background: `color-mix(in srgb, ${enabled ? TOKENS.cyan : TOKENS.inkSoft} 3%, white)` }}
                      >
                        <div className="absolute inset-y-0 left-0 w-[3px]" style={{ background: enabled ? TOKENS.cyan : TOKENS.inkSoft }} />
                        <div className="flex items-start justify-between gap-3 pl-1.5">
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span
                                className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide"
                                style={{
                                  background: enabled ? `color-mix(in srgb, ${TOKENS.cyan} 16%, white)` : "#F1F5F9",
                                  color: enabled ? "#0F7A5C" : TOKENS.inkSoft,
                                }}
                              >
                                <span className="h-1.5 w-1.5 rounded-full" style={{ background: enabled ? "#12B981" : TOKENS.inkSoft }} />
                                {enabled ? "Active" : "Paused"}
                              </span>
                              <span className="rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide" style={{ background: `color-mix(in srgb, ${TOKENS.blue} 12%, white)`, color: TOKENS.blue }}>
                                {s.frequency || "—"}
                              </span>
                            </div>
                            <p className="mt-2.5 truncate text-[13.5px] font-bold" style={{ color: TOKENS.ink }}>{summary}</p>
                            <p className="mt-1 flex items-center gap-1.5 truncate text-[11.5px]" style={{ color: TOKENS.inkSoft }}>
                              <Mail size={12} className="shrink-0" />
                              {s.recipientEmail || "—"}
                            </p>
                            <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10.5px]" style={{ color: TOKENS.inkSoft }}>
                              <span className="inline-flex items-center gap-1"><Globe size={11} /> {s.timeZone || "—"}</span>
                              {s.cronExpression && (
                                <span className="font-mono tabular-nums opacity-80">{s.cronExpression}</span>
                              )}
                            </div>
                            {(s.createdAt || s.updatedAt) && (
                              <p className="mt-1.5 text-[10px]" style={{ color: TOKENS.inkSoft }}>
                                Updated {formatMemberSince(s.updatedAt || s.createdAt)}
                              </p>
                            )}
                          </div>
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl" style={{ background: `color-mix(in srgb, ${TOKENS.blue} 12%, white)`, color: TOKENS.blue }}>
                            <Clock size={18} />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <Modal open={scheduleModalOpen} onClose={() => !scheduleSaving && setScheduleModalOpen(false)} width={720}>
                <form onSubmit={handleScheduleSave}>
                  <div
                    className="relative overflow-hidden px-6 pb-5 pt-6"
                    style={{ background: `linear-gradient(140deg, ${TOKENS.indigo} 0%, ${TOKENS.blue} 50%, ${TOKENS.cyan} 140%)` }}
                  >
                    <div className="pointer-events-none absolute -right-10 -top-14 h-44 w-44 rounded-full bg-white/10 blur-3xl" />
                    <div className="pointer-events-none absolute -bottom-16 left-16 h-32 w-32 rounded-full bg-white/10 blur-3xl" />
                    <div className="relative flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/15 text-white ring-1 ring-white/25 backdrop-blur">
                          <Send size={18} />
                        </div>
                        <div>
                          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/70">New schedule</p>
                          <p className="text-[16px] font-extrabold text-white" style={{ fontFamily: FONT_DISPLAY }}>Create report schedule</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => !scheduleSaving && setScheduleModalOpen(false)}
                        className="pe-focus-ring flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/80 transition hover:bg-white/15 hover:text-white"
                        aria-label="Close"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>

                  <div className="max-h-[68vh] overflow-y-auto pe-scrollbar p-5">
                    <div className="grid grid-cols-1 gap-4 lg:grid-cols-[200px,1fr]">
                      <div className="rounded-2xl border p-4 text-center" style={{ borderColor: TOKENS.line, background: `linear-gradient(165deg, color-mix(in srgb, ${TOKENS.indigo} 6%, white), white)` }}>
                        <span
                          className="mb-2 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide"
                          style={{
                            background: scheduleForm.enabled ? `color-mix(in srgb, ${TOKENS.cyan} 16%, white)` : "#F1F5F9",
                            color: scheduleForm.enabled ? "#0F7A5C" : TOKENS.inkSoft,
                          }}
                        >
                          <span className="h-1.5 w-1.5 rounded-full" style={{ background: scheduleForm.enabled ? "#12B981" : TOKENS.inkSoft }} />
                          {scheduleForm.enabled ? "Active" : "Paused"}
                        </span>
                        <ScheduleClock hour={scheduleForm.hourOfDay} minute={scheduleForm.minuteOfHour} />
                        <p className="mt-2 text-[12px] font-bold" style={{ color: TOKENS.ink }}>{formatScheduleSummary(scheduleForm)}</p>
                        <p className="mt-0.5 truncate text-[10.5px]" style={{ color: TOKENS.inkSoft }}>{scheduleForm.timeZone}</p>
                      </div>

                      <div className="space-y-3.5">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <p className="text-[12px] font-bold" style={{ color: TOKENS.ink }}>Schedule settings</p>
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-bold" style={{ color: TOKENS.inkSoft }}>{scheduleForm.enabled ? "Enabled" : "Disabled"}</span>
                            <ScheduleToggle checked={scheduleForm.enabled} onChange={(v) => setScheduleForm((f) => ({ ...f, enabled: v }))} />
                          </div>
                        </div>

                        <div>
                          <p className="mb-1.5 text-[10.5px] font-bold uppercase tracking-wide" style={{ color: TOKENS.inkSoft }}>Frequency</p>
                          <div className="flex w-fit flex-wrap items-center gap-1 rounded-xl border bg-[#F8F9FC] p-1" style={{ borderColor: TOKENS.line }}>
                            {FREQUENCY_OPTIONS.map((o) => {
                              const active = scheduleForm.frequency === o.value;
                              return (
                                <button
                                  key={o.value}
                                  type="button"
                                  onClick={() => setScheduleForm((f) => ({ ...f, frequency: o.value }))}
                                  className="rounded-lg px-3.5 py-1.5 text-[11.5px] font-bold transition"
                                  style={{ color: active ? "#fff" : TOKENS.inkSoft, background: active ? `linear-gradient(135deg, ${TOKENS.blue}, ${TOKENS.cyan})` : "transparent" }}
                                >
                                  {o.label}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <FieldShell label="Send time" icon={Clock}>
                            <input
                              type="time"
                              required
                              className={glossyInputClass}
                              style={glossyInputStyle}
                              value={`${pad2(scheduleForm.hourOfDay)}:${pad2(scheduleForm.minuteOfHour)}`}
                              onChange={(e) => {
                                const [h, m] = e.target.value.split(":").map(Number);
                                setScheduleForm((f) => ({ ...f, hourOfDay: h, minuteOfHour: m }));
                              }}
                            />
                          </FieldShell>
                          <FieldShell label="Time zone" icon={Globe}>
                            <select
                              className={glossyInputClass}
                              style={glossyInputStyle}
                              value={scheduleForm.timeZone}
                              onChange={(e) => setScheduleForm((f) => ({ ...f, timeZone: e.target.value }))}
                            >
                              {TIMEZONE_OPTIONS.map((tz) => (
                                <option key={tz} value={tz}>{tz}</option>
                              ))}
                            </select>
                          </FieldShell>
                        </div>

                        {scheduleForm.frequency === "WEEKLY" && (
                          <div>
                            <p className="mb-1.5 text-[10.5px] font-bold uppercase tracking-wide" style={{ color: TOKENS.inkSoft }}>Day of week</p>
                            <div className="flex flex-wrap gap-1.5">
                              {DAY_OF_WEEK_OPTIONS.map((d) => {
                                const active = scheduleForm.dayOfWeek === d.value;
                                return (
                                  <button
                                    key={d.value}
                                    type="button"
                                    onClick={() => setScheduleForm((f) => ({ ...f, dayOfWeek: d.value }))}
                                    className="flex h-9 w-9 items-center justify-center rounded-xl text-[11px] font-bold transition"
                                    style={{
                                      border: `1px solid ${active ? "transparent" : TOKENS.line}`,
                                      color: active ? "#fff" : TOKENS.ink,
                                      background: active ? `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.blue})` : "white",
                                    }}
                                  >
                                    {d.label}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {scheduleForm.frequency === "MONTHLY" && (
                          <FieldShell label="Day of month" icon={CalendarDays}>
                            <input
                              type="number"
                              min={1}
                              max={31}
                              required
                              className={glossyInputClass}
                              style={glossyInputStyle}
                              value={scheduleForm.dayOfMonth}
                              onChange={(e) => setScheduleForm((f) => ({ ...f, dayOfMonth: Number(e.target.value) }))}
                            />
                          </FieldShell>
                        )}

                        <FieldShell label="Recipient email" icon={Mail}>
                          <input
                            type="email"
                            required
                            placeholder="reports@yourcompany.com"
                            className={glossyInputClass}
                            style={glossyInputStyle}
                            value={scheduleForm.recipientEmail}
                            onChange={(e) => setScheduleForm((f) => ({ ...f, recipientEmail: e.target.value }))}
                          />
                        </FieldShell>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 border-t px-5 py-4" style={{ borderColor: TOKENS.line }}>
                    <RippleButton type="button" variant="secondary" onClick={() => setScheduleModalOpen(false)} disabled={scheduleSaving}>
                      Cancel
                    </RippleButton>
                    <RippleButton
                      type="submit"
                      disabled={scheduleSaving}
                      className="pe3d-shine"
                      style={{ background: `linear-gradient(135deg, ${TOKENS.indigo}, ${TOKENS.blue})`, boxShadow: `0 12px 26px -10px color-mix(in srgb, ${TOKENS.blue} 60%, transparent)` }}
                    >
                      {scheduleSaving ? <Loader2 size={13} className="pe-refresh-spin" /> : <Check size={13} />}
                      {scheduleSaving ? "Saving…" : "Save schedule"}
                    </RippleButton>
                  </div>
                </form>
              </Modal>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export { ProfileTab, CompanyTab };